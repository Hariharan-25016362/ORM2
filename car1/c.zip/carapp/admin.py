from .models import Car, CarAdmin
from django.contrib import admin

admin.site.register(Car,CarAdmin)